from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.db.models import Avg, F
from django.contrib.auth.models import User

from .models import Course, Question, Option, Exam, ExamAttempt, Answer
from .forms import CourseForm, QuestionForm, ExamForm

@login_required
def dashboard(request):
    if request.user.is_staff:
        total_exams = Exam.objects.count()
        total_questions = Question.objects.count()
        total_students = User.objects.filter(is_staff=False).count()
        recent_attempts = ExamAttempt.objects.select_related('student', 'exam').order_by('-created_at')[:5]
        
        total_attempts = ExamAttempt.objects.count()
        completed_attempts = ExamAttempt.objects.filter(is_completed=True).count()
        avg_score = ExamAttempt.objects.filter(is_completed=True).aggregate(Avg('score'))['score__avg'] or 0
        
        context = {
            'total_exams': total_exams,
            'total_questions': total_questions,
            'total_students': total_students,
            'total_attempts': total_attempts,
            'completed_attempts': completed_attempts,
            'avg_score': round(avg_score, 2),
            'recent_attempts': recent_attempts,
        }
        return render(request, 'exams/admin_dashboard.html', context)
    else:
        assigned_exams = request.user.assigned_exams.filter(status='published')
        recent_attempts = request.user.exam_attempts.select_related('exam').order_by('-created_at')[:5]
        
        context = {
            'assigned_exams': assigned_exams,
            'recent_attempts': recent_attempts,
        }
        return render(request, 'exams/student_dashboard.html', context)

@login_required
def my_exams(request):
    if request.user.is_staff:
        return redirect('dashboard')
    
    assigned_exams = request.user.assigned_exams.filter(status='published')
    attempts = request.user.exam_attempts.select_related('exam').all()
    
    exam_attempts = {}
    for attempt in attempts:
        exam_attempts[attempt.exam.id] = attempt
    
    context = {
        'assigned_exams': assigned_exams,
        'exam_attempts': exam_attempts,
    }
    return render(request, 'exams/my_exams.html', context)

class CourseListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = Course
    template_name = 'exams/course_list.html'
    context_object_name = 'courses'
    
    def test_func(self):
        return self.request.user.is_staff

class CourseCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Course
    form_class = CourseForm
    template_name = 'exams/course_form.html'
    success_url = reverse_lazy('course_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Course created successfully!')
        return super().form_valid(form)

class CourseUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Course
    form_class = CourseForm
    template_name = 'exams/course_form.html'
    success_url = reverse_lazy('course_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Course updated successfully!')
        return super().form_valid(form)

class CourseDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Course
    template_name = 'exams/course_confirm_delete.html'
    success_url = reverse_lazy('course_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Course deleted successfully!')
        return super().delete(request, *args, **kwargs)

class QuestionListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = Question
    template_name = 'exams/question_list.html'
    context_object_name = 'questions'
    paginate_by = 20
    
    def test_func(self):
        return self.request.user.is_staff

class QuestionCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Question
    form_class = QuestionForm
    template_name = 'exams/question_form.html'
    success_url = reverse_lazy('question_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Question created successfully!')
        return super().form_valid(form)

class QuestionDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = Question
    template_name = 'exams/question_detail.html'
    context_object_name = 'question'
    
    def test_func(self):
        return self.request.user.is_staff

class QuestionUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Question
    form_class = QuestionForm
    template_name = 'exams/question_form.html'
    success_url = reverse_lazy('question_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Question updated successfully!')
        return super().form_valid(form)

class QuestionDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Question
    template_name = 'exams/question_confirm_delete.html'
    success_url = reverse_lazy('question_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Question deleted successfully!')
        return super().delete(request, *args, **kwargs)

class ExamListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = Exam
    template_name = 'exams/exam_list.html'
    context_object_name = 'exams'
    paginate_by = 20
    
    def test_func(self):
        return self.request.user.is_staff

class ExamCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Exam
    form_class = ExamForm
    template_name = 'exams/exam_form.html'
    success_url = reverse_lazy('exam_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Exam created successfully!')
        return super().form_valid(form)

class ExamDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = Exam
    template_name = 'exams/exam_detail.html'
    context_object_name = 'exam'
    
    def test_func(self):
        return self.request.user.is_staff
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['attempts'] = self.object.attempts.select_related('student').order_by('-created_at')
        return context

class ExamUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Exam
    form_class = ExamForm
    template_name = 'exams/exam_form.html'
    success_url = reverse_lazy('exam_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def form_valid(self, form):
        messages.success(self.request, 'Exam updated successfully!')
        return super().form_valid(form)

class ExamDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Exam
    template_name = 'exams/exam_confirm_delete.html'
    success_url = reverse_lazy('exam_list')
    
    def test_func(self):
        return self.request.user.is_staff
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Exam deleted successfully!')
        return super().delete(request, *args, **kwargs)

@login_required
def assign_questions_to_exam(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden()
    
    exam = get_object_or_404(Exam, pk=pk)
    return render(request, 'exams/assign_questions.html', {'exam': exam})

@login_required
def assign_users_to_exam(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden()
    
    exam = get_object_or_404(Exam, pk=pk)
    return render(request, 'exams/assign_users.html', {'exam': exam})

@login_required
def take_exam(request, pk):
    if request.user.is_staff:
        return HttpResponseForbidden()
    
    exam = get_object_or_404(Exam, pk=pk, status='published')
    return render(request, 'exams/take_exam.html', {'exam': exam})

@login_required
def exam_results(request, attempt_id):
    attempt = get_object_or_404(ExamAttempt, id=attempt_id)
    
    if not request.user.is_staff and request.user != attempt.student:
        return HttpResponseForbidden()
    
    return render(request, 'exams/exam_results.html', {'attempt': attempt})

@login_required
def all_results(request):
    if not request.user.is_staff:
        return HttpResponseForbidden()
    
    attempts = ExamAttempt.objects.select_related('student', 'exam').filter(is_completed=True).order_by('-created_at')
    
    exam_filter = request.GET.get('exam')
    if exam_filter:
        attempts = attempts.filter(exam_id=exam_filter)
    
    total_attempts = attempts.count()
    passed_attempts = attempts.filter(score__gte=F('exam__passing_marks')).count()
    avg_score = attempts.aggregate(Avg('score'))['score__avg'] or 0
    
    context = {
        'attempts': attempts,
        'total_attempts': total_attempts,
        'passed_attempts': passed_attempts,
        'avg_score': round(avg_score, 2),
        'exams': Exam.objects.all(),
        'selected_exam': exam_filter,
    }
    return render(request, 'exams/all_results.html', context) 