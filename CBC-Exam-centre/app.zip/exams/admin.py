from django.contrib import admin
from .models import Course, Question, Option, Exam, ExamAttempt, Answer

class OptionInline(admin.TabularInline):
    model = Option
    extra = 4
    fields = ['text', 'is_correct']

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name', 'description']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['question_text', 'question_type', 'difficulty', 'score', 'category', 'created_at']
    list_filter = ['question_type', 'difficulty', 'category', 'created_at']
    search_fields = ['question_text', 'category']
    readonly_fields = ['created_at', 'updated_at']
    inlines = [OptionInline]
    
    fieldsets = (
        ('Question Information', {
            'fields': ('question_text', 'question_type', 'difficulty', 'score', 'category')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ['title', 'course', 'duration_minutes', 'total_marks', 'passing_marks', 'status', 'created_at']
    list_filter = ['status', 'course', 'created_at']
    search_fields = ['title', 'description', 'course__name']
    readonly_fields = ['created_at', 'updated_at']
    filter_horizontal = ['questions', 'assigned_users']
    
    fieldsets = (
        ('Exam Information', {
            'fields': ('title', 'description', 'course', 'status')
        }),
        ('Exam Settings', {
            'fields': ('duration_minutes', 'total_marks', 'passing_marks')
        }),
        ('Scheduling', {
            'fields': ('start_date', 'end_date')
        }),
        ('Content & Users', {
            'fields': ('questions', 'assigned_users')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(ExamAttempt)
class ExamAttemptAdmin(admin.ModelAdmin):
    list_display = ['student', 'exam', 'start_time', 'end_time', 'score', 'is_completed']
    list_filter = ['is_completed', 'start_time', 'exam__course']
    search_fields = ['student__username', 'student__email', 'exam__title']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Attempt Information', {
            'fields': ('student', 'exam', 'is_completed')
        }),
        ('Timing', {
            'fields': ('start_time', 'end_time')
        }),
        ('Results', {
            'fields': ('score',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['exam_attempt', 'question', 'marks_obtained', 'created_at']
    list_filter = ['created_at', 'question__question_type']
    search_fields = ['exam_attempt__student__username', 'question__question_text']
    readonly_fields = ['created_at', 'updated_at']
    filter_horizontal = ['selected_options']
    
    fieldsets = (
        ('Answer Information', {
            'fields': ('exam_attempt', 'question')
        }),
        ('Response', {
            'fields': ('selected_options', 'text_answer')
        }),
        ('Results', {
            'fields': ('marks_obtained',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
