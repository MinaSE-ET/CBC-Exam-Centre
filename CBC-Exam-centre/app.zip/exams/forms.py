from django import forms
from django.forms import inlineformset_factory
from .models import Question, Option, Exam, Course, ExamAttempt, Answer

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['question_text', 'question_type', 'difficulty', 'score', 'category']
        widgets = {
            'question_text': forms.Textarea(attrs={'rows': 4}),
            'category': forms.TextInput(attrs={'placeholder': 'e.g., Mathematics, Science, etc.'}),
        }

class OptionForm(forms.ModelForm):
    class Meta:
        model = Option
        fields = ['text', 'is_correct']
        widgets = {
            'text': forms.TextInput(attrs={'placeholder': 'Enter option text'}),
        }

# Inline formset for options
OptionFormSet = inlineformset_factory(
    Question, Option,
    form=OptionForm,
    extra=4,
    min_num=2,
    max_num=6,
    can_delete=True,
    validate_min=True,
    validate_max=True,
)

class ExamForm(forms.ModelForm):
    class Meta:
        model = Exam
        fields = [
            'title', 'description', 'course', 'duration_minutes', 
            'total_marks', 'passing_marks', 'status', 'start_date', 'end_date'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'start_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'end_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        passing_marks = cleaned_data.get('passing_marks')
        total_marks = cleaned_data.get('total_marks')
        
        if passing_marks and total_marks and passing_marks > total_marks:
            raise forms.ValidationError("Passing marks cannot be greater than total marks.")
        
        return cleaned_data

class ExamQuestionAssignmentForm(forms.ModelForm):
    class Meta:
        model = Exam
        fields = ['questions']
        widgets = {
            'questions': forms.CheckboxSelectMultiple(),
        }

class ExamUserAssignmentForm(forms.ModelForm):
    class Meta:
        model = Exam
        fields = ['assigned_users']
        widgets = {
            'assigned_users': forms.CheckboxSelectMultiple(),
        }

class ExamTakingForm(forms.Form):
    def __init__(self, question, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.question = question
        
        if question.question_type == 'single_choice':
            self.fields['answer'] = forms.ChoiceField(
                choices=[(option.id, option.text) for option in question.options.all()],
                widget=forms.RadioSelect,
                label=question.question_text,
                required=True
            )
        elif question.question_type == 'multiple_choice':
            self.fields['answer'] = forms.MultipleChoiceField(
                choices=[(option.id, option.text) for option in question.options.all()],
                widget=forms.CheckboxSelectMultiple,
                label=question.question_text,
                required=True
            )

class ExamSearchForm(forms.Form):
    search = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Search exams...'})
    )
    status = forms.ChoiceField(
        choices=[('', 'All Statuses')] + Exam.STATUS_CHOICES,
        required=False
    )
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        required=False,
        empty_label="All Courses"
    )

class QuestionSearchForm(forms.Form):
    search = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Search questions...'})
    )
    question_type = forms.ChoiceField(
        choices=[('', 'All Types')] + Question.QUESTION_TYPES,
        required=False
    )
    difficulty = forms.ChoiceField(
        choices=[('', 'All Difficulties')] + Question.DIFFICULTY_LEVELS,
        required=False
    )
    category = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Filter by category...'})
    ) 